'''
Created on 17.10.2013
@author: tbu
'''

import arcpy

sde = arcpy.GetParameterAsText(0)
editor = arcpy.GetParameterAsText(1)
viewer = arcpy.GetParameterAsText(2)
sdeConn = arcpy.ArcSDESQLExecute(sde)

# executes the list of sql DDL in SQLStatement against the sde connection sdeConn
def ExecuteDDL(sdeConn, SQLStatement):
    SQLStatementList = SQLStatement.split(";")
    
    # For each SQL statement passed in, execute it.
    for sql in SQLStatementList:
        #arcpy.AddMessage("Execute SQL Statement: " + sql)
        try:
            # Pass the SQL statement to the database.
            sdeConn.execute(sql)
            arcpy.AddMessage( "SQL statement: " + sql + " ran sucessfully." )
        except Exception, ErrorDesc:
            arcpy.AddWarning( "SQL statement: " + sql + " FAILED.")
            arcpy.AddError( ErrorDesc )

def DeleteRights(sdeConn):
    SQLStatement = "REVOKE ALL TO {0};".format(editor)
    SQLStatement = SQLStatement + "REVOKE ALL TO {0}".format(viewer)
    ExecuteDDL(sdeConn, SQLStatement)

def DeleteSchemas(sdeConn):
    SQLStatement = "DROP SCHEMA {0};".format(editor)
    SQLStatement = SQLStatement + "DROP SCHEMA {0}".format(viewer)
    ExecuteDDL(sdeConn, SQLStatement)

def GrantExecuteToRoles(sdeConn):
    SQLStatement = "GRANT EXECUTE TO [R_SDE_OWNER];" \
                   "GRANT EXECUTE TO [R_SDE_EDITOR];" \
                   "GRANT EXECUTE TO [R_SDE_VIEWER]"
    ExecuteDDL(sdeConn, SQLStatement)

DeleteRights(sdeConn)             
DeleteSchemas(sdeConn)
GrantExecuteToRoles(sdeConn)
